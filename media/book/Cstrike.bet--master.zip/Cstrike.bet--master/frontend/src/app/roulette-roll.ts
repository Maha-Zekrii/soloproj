export class RouletteRoll {
  round: number;
  winningNumber: number;
  date: string;
}
