

export class Affiliate {
  id: string;
  promo: string;
  referredBy: string;
  referred: string[];
  currentBalance: number;
}
