
export class RouletteBet {
   betName: string;
   id: string;
   betPicture: string;
   bet: number;
   color: number;
}

/**
COLOR:
0 = red
1 = Green
2 = black

*/
