# Cstrike.bet
This is the source for a CSGO Roulette site I created a while back. It has code for the frontend design in Angular, the backend game and user logic in nodejs, and the steam trading bots which are also written in nodejs. 

![Betting](https://i.gyazo.com/40bb256293eb6109d22826ba64c7ff48.gif)
![Spinning Finish](https://i.gyazo.com/b65577e0ec3b70520cb3638f40d013be.gif)
![Deposit](https://https://i.gyazo.com/3e5a8c98d5ab6c21ac08b080f20e7cac.gif)
![Loading Slow Connection](https://i.gyazo.com/c6723e5b5f4f475fc3c2c542d63e4900.gif)
